# -*- coding: UTF-8 -*-

from resources.lib.modules import control

AddonTitle = control.AddonTitle

def TestMenu():
    my_options = ['Option 1', 'Option 2', 'Option 3', 'Option 4', 'Option 5']
    mychoice = control.SelectDialog(AddonTitle, my_options, key=False)
    if mychoice == 'Option 1':
        control.Notify(AddonTitle, 'Testing Option 1...')
    elif mychoice == 'Option 2':
        control.Notify(AddonTitle, 'Testing Option 2...')
    elif mychoice == 'Option 3':
        control.Notify(AddonTitle, 'Testing Option 3...')
    elif mychoice == 'Option 4':
        control.Notify(AddonTitle, 'Testing Option 4...')
    elif mychoice == 'Option 5':
        control.Notify(AddonTitle, 'Testing Option 5...')


def mySpareMenu():
    my_options = ['Option1', 'Option2', 'Option3', 'Option4', 'Option5', '[ [B]Close[/B] ]']
    mychoice = SelectDialog(AddonTitle, my_options, key=False)
    if mychoice == 'Option1': Notify(AddonTitle, 'Testing Option1...')
    elif mychoice == 'Option2': Notify(AddonTitle, 'Testing Option2...')
    elif mychoice == 'Option3': Notify(AddonTitle, 'Testing Option3...')
    elif mychoice == 'Option4': Notify(AddonTitle, 'Testing Option4...')
    elif mychoice == 'Option5':
        Notify(AddonTitle, 'Testing Option5...')
    elif mychoice == '[ [B]Close[/B] ]' :
        return

