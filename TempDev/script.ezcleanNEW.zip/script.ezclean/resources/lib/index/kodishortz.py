# -*- coding: UTF-8 -*-

from resources.lib.modules import control

AddonTitle = control.AddonTitle
SelectDialog = control.SelectDialog
Execute = control.execute
Notify = control.Notify


def kodiMenu():
    my_options = ['FileManager', 'AddonBrowser', 'InterfaceSettings', 'SystemSettings', 'ShowSettings', 'SkinSettings', 'ShowSystemInfo', '[ [B]Close[/B] ]']
    mychoice = SelectDialog(AddonTitle, my_options, key=False)
    if mychoice == 'FileManager': Execute("ActivateWindow(10003)")
    elif mychoice == 'AddonBrowser': Execute("ActivateWindow(10040)")
    elif mychoice == 'InterfaceSettings': Execute("ActivateWindow(10032)")
    elif mychoice == 'SystemSettings': Execute("ActivateWindow(10016)")
    elif mychoice == 'ShowSettings': Execute("ActivateWindow(10004)")
    elif mychoice == 'SkinSettings': Execute("ActivateWindow(10035)")
    elif mychoice == 'ShowSystemInfo': Execute("ActivateWindow(10007)")
    elif mychoice == '[ [B]Close[/B] ]': return


def morekodiMenu():
    my_options = ['CleanPlaylist', 'UpdateVideoDB', 'CleanVideoDB', 'UpdateMusicDB', 'CleanMusicDB', '[ [B]Close[/B] ]']
    mychoice = SelectDialog(AddonTitle, my_options, key=False)
    if mychoice == 'CleanPlaylist': Execute("Playlist.Clear")
    elif mychoice == 'UpdateVideoDB': Execute("UpdateLibrary(video)")
    elif mychoice == 'CleanVideoDB': Execute("CleanLibrary(video)")
    elif mychoice == 'UpdateMusicDB': Execute("UpdateLibrary(music)")
    elif mychoice == 'CleanMusicDB': Execute("CleanLibrary(music)")
    elif mychoice == '[ [B]Close[/B] ]' : return


def mainShortzMenu():
    my_options = ['kodiMenu', 'morekodiMenu', '[ [B] Close [/B] ]']
    mychoice = SelectDialog(AddonTitle, my_options, key=False)
    if mychoice == 'kodiMenu': kodiMenu()
    elif mychoice == 'morekodiMenu': morekodiMenu()
    elif mychoice == '[ [B] Close [/B] ]': return


