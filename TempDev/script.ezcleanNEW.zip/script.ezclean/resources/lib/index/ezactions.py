# -*- coding: UTF-8 -*-

import os
from resources.lib.modules import control

AddonID = control.AddonID
AddonTitle = control.AddonTitle
SelectDialog = control.SelectDialog


def actCleanMenu():
    from resources.lib.modules import clean
    my_options = ['Delete_Cache', 'Clear_Thumb', 'Delete_Packages', '[ [B] Close [/B] ]']
    mychoice = SelectDialog(AddonTitle, my_options, key=False)
    if mychoice == 'Delete_Cache':
        clean.Delete_Cache(url)
    elif mychoice == 'Clear_Thumb':
        clean.Clear_Thumb()
    elif mychoice == 'Delete_Packages':
        clean.Delete_Packages(url)
    elif mychoice == '[ [B] Close [/B] ]':
        return


def actChangeLog():
    changelogfile = control.transPath(os.path.join('special://home/addons/' + AddonID, 'changelog.txt'))
    my_options = ['DialogWindow', 'TextViewer', '[ [B] Close [/B] ]']
    mychoice = SelectDialog(AddonTitle, my_options, key=False)
    if mychoice == 'DialogWindow':
        control.getChangeLog()
    elif mychoice == 'TextViewer':
        from resources.lib.api import TextViewer
        TextViewer.text_view(changelogfile)
    elif mychoice == '[ [B] Close [/B] ]':
        return

































