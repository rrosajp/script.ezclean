# -*- coding: UTF-8 -*-

import os,sys,urllib
from resources.lib.modules import control


AddonID = control.AddonID
MENU_FANART = control.AddonFanart
MENU_ICON = "DefaultAddonProgram.png"
CustomColor = control.setting('my_ColorChoice')
if CustomColor == '': CustomColor = 'none'


def setView(content, viewType):
    if content:
        control.content(int(sys.argv[1]), content)
    if control.getSetting('auto-view')=='true':
        views = control.getSetting('viewType2')
        if views == '50' and control.getKodiVersion >= 17 and control.skin == 'skin.estuary': views = '55'
        if views == '500' and control.getKodiVersion >= 17 and control.skin == 'skin.estuary': views = '50'
        return control.execute("Container.SetViewMode(%s)" % views)
    else:
        views = control.getCurrentViewId()
        return control.execute("Container.SetViewMode(%s)" % views)


def CreateDir(name, url, action, icon, fanart, description, isFolder=False):
    if icon == None or icon == '': icon = MENU_ICON
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&action="+str(action)+"&name="+urllib.quote_plus(name)+"&icon="+urllib.quote_plus(icon)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
    ok=True
    name = '[COLOR %s][B]%s[/B][/COLOR]' % (CustomColor, name)
    liz=control.item(name, iconImage="DefaultAddonProgram.png", thumbnailImage=icon)
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    liz.setProperty("Fanart_Image", fanart)
    ok=control.addItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
    return ok


def CATEGORIES():
    setView('addons', 'views')
    CreateDir('QuikTest', 'url', 'QuikTest', MENU_ICON, MENU_FANART, 'description')
    CreateDir('cleanMenu', 'url', 'cleanMenu', MENU_ICON, MENU_FANART, 'description')
    CreateDir('kodishortz', 'url', 'kodishortz', MENU_ICON, MENU_FANART, 'description')
    CreateDir('AdvancedSettings', 'url', 'advancedSettings', MENU_ICON, MENU_FANART, 'advancedSettings')
    CreateDir('Settings', 'url', 'settings', MENU_ICON, MENU_FANART, 'settings')
    CreateDir('changeLog', 'url', 'changeLog', control.AddonIcon, MENU_FANART, 'description')


params = control.get_params()
url = None
try: url = urllib.unquote_plus(params["url"])
except: pass
action = None
try: action = urllib.unquote_plus(params["action"])
except: pass
name = None
try: name = urllib.unquote_plus(params["name"])
except: pass
icon = None
try: icon = urllib.unquote_plus(params["icon"])
except: pass
fanart = None
try: fanart = urllib.unquote_plus(params["fanart"])
except: pass
description = None
try: description = urllib.unquote_plus(params["description"])
except: pass
mode = None
try: mode = urllib.unquote_plus(params["mode"])
except: pass


if action == None: CATEGORIES()

elif action == 'settings': control.openSettings()

elif action == 'colorChoice':
    from resources.lib.api import colorChoice
    colorChoice.colorChoice()

elif action == 'viewTypes':
    from resources.lib.api import viewTypes
    viewTypes.getViewType()

elif action == 'changeLog':
    from resources.lib.index import ezactions
    ezactions.actChangeLog()


elif action == 'kodishortz': 
    from resources.lib.index import kodishortz
    kodishortz.mainShortzMenu()


elif action == 'advancedSettings': 
    from resources.lib.modules import advsetz
    advsetz.advancedSettingsMenu()


elif action == 'cleanMenu':
    from resources.lib.index import ezactions
    ezactions.actCleanMenu()


elif action == 'QuikTest':
    from resources.lib.api import TextViewer
    TextViewer.text_view(AdvancedSettingsFile)




control.directory(int(sys.argv[1]))

